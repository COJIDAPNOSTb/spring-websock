package org.example.springwebsocket.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class qwe {
	
	@GetMapping("/qwe")
	public String iu() {
		return "asdfghgfdsa";
	}
}
