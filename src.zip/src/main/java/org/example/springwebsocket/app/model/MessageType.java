package org.example.springwebsocket.app.model;

public enum MessageType {
    CHAT, JOIN, LEAVE
}
